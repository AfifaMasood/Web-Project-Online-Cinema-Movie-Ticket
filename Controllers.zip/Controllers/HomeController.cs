﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Domain.Interface;
using Domain.Entities;
using Application;
using Infrastructure;
using System.Diagnostics;
using System.Web;

namespace practice.Controllers
{
    //[Authorize(Policy = "PakistaniPolicy")]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public ViewResult Index()
        {
            string data = string.Empty;
            if (HttpContext.Request.Cookies.ContainsKey("first_request"))
            {
                string firstVisitedDateTime = HttpContext.Request.Cookies["first_request"];
                data = "Welcome Back User! " + firstVisitedDateTime;
            }
            else
            {

                CookieOptions options = new CookieOptions();
                options.Expires = DateTime.Now.AddDays(30);
                data = "Hey User! you are visiting here for the first time...";
                HttpContext.Response.Cookies.Append("first_request", System.DateTime.Now.ToString(), options);

            }
            ViewBag.Data = data;
            return View();
        }

        public IActionResult Remove()
        {
           
            HttpContext.Response.Cookies.Delete("first_request");
            return View("Index");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}