﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Xml.Linq;
using Microsoft.AspNetCore.Authorization;
using System.IO;
using static System.Net.Mime.MediaTypeNames;
using System.Runtime.Serialization.Formatters.Binary;
using System.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Domain.Interface;
using Domain.Entities;
using Application;
using Infrastructure;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using System.Runtime.Caching;
using practice.Controllers;

namespace Project_Task.Controllers
{
    public class MoviesController : Controller
    {
        private readonly IRepository<SeatReserved> _repository;
        private readonly IMovie _movie;
        private readonly SeatRepoDecorator _seat;
        private readonly IMemoryCache _cache;
        private readonly ILogger<MoviesController> _logger;
       

        public MoviesController(IMemoryCache cache, ILogger<MoviesController> logger, IRepository<SeatReserved> repository, SeatRepoDecorator seat, IMovie movie)
        {
            _repository = repository;
            _seat = seat;
            _movie = movie;
            _cache = cache;
            _logger = logger;
        }

        public async Task<ViewResult> Movies()
        {
            _logger.LogTrace("Movies method started.");
            return View();
        }

        public async Task<ViewResult> NotBooking()
        {
            _logger.LogTrace("Not Booking method started.");
            return View();
        }

        public async Task<JsonResult> PreviousBooking()
        {
            string userName = HttpContext.User.Identity.Name;
            var result = await _seat.SGetAllAsync(userName);
            List<SeatReserved> seatReservedList = result.Item1;
            List<MovieShows> movieShowsList = result.Item2;

            _logger.LogTrace("Previous Booking method started.");

            BookingViewModel viewModel = new BookingViewModel
            {
                SeatReservedList = seatReservedList,
                MovieShowsList = movieShowsList
            };

            return Json(viewModel);
        }

        //[Authorize(Policy = "PakistaniPolicy")]
        //[Authorize(Policy = "LoggedInPolicy")]
        //public async Task<ActionResult> Booking()
        //{
        //    string userName = HttpContext.User.Identity.Name;
        //    string message = TempData["Booking"] as string;
        //    TempData["Booking"] = message;

        //    if (!string.IsNullOrEmpty(userName))
        //    {
        //        var result = await _seat.SGetAllAsync(userName);
        //        List<SeatReserved> seatReservedList = result.Item1;
        //        List<MovieShows> movieShowsList = result.Item2;

        //        if (seatReservedList.Count == 0)
        //        {
        //            return RedirectToAction("NotBooking", "Movies");
        //        }
        //        else
        //        {
        //            BookingViewModel viewModel = new BookingViewModel
        //            {
        //                SeatReservedList = seatReservedList,
        //                MovieShowsList = movieShowsList
        //            };

        //            return View(viewModel);
        //        }
        //    }
        //    else
        //    {
        //        return Content("Please login to continue.");
        //    }
        //}


        public async Task<ActionResult> Booking()
        {
            string userName = HttpContext.User.Identity.Name;
            string message = TempData["Booking"] as string;
            List<SeatReserved> seatReservedList = new List<SeatReserved>();
            List<MovieShows> movieShowsList = new List<MovieShows>();

            if (string.IsNullOrEmpty(userName))
            {
                return Content("Please login to continue.");
            }

            if (!_cache.TryGetValue($"BookingData_{userName}", out (List<SeatReserved> cachedSeatReservedList, List<MovieShows> cachedMovieShowsList) cachedData))
            {
                _logger.LogTrace("Data stored in cache.");
                var result = await _seat.SGetAllAsync(userName);
                seatReservedList = result.Item1;
                movieShowsList = result.Item2;

                if (seatReservedList.Count == 0)
                {
                    return RedirectToAction("NotBooking", "Movies");
                }

                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    .SetAbsoluteExpiration(TimeSpan.FromMinutes(5));
                _cache.Set($"BookingData_{userName}", (seatReservedList, movieShowsList), cacheEntryOptions);
            }
            else
            {
                _logger.LogTrace("Data retrieved from cache");
                seatReservedList = cachedData.Item1;
                movieShowsList = cachedData.Item2;
            }

            var viewModel = new BookingViewModel
            {
                SeatReservedList = seatReservedList,
                MovieShowsList = movieShowsList
            };

            return View(viewModel);
        }



        //[Authorize(Policy = "PakistaniPolicy")]
        //[Authorize(Policy = "LoggedInPolicy")]
        //public async Task<IActionResult> Booking()
        //{
        //    string userName = HttpContext.User.Identity.Name;
        //    string _cacheKey = $"BookingData_{userName}";
        //    string message = TempData["Booking"] as string;
        //    TempData["Booking"] = message;

        //    if (!string.IsNullOrEmpty(userName))
        //    {


        //        if (cache.Contains(_cacheKey))
        //        {
        //            var cachedData = (Tuple<List<SeatReserved>, List<MovieShows>>)cache.Get(_cacheKey);

        //            BookingViewModel viewModel = new BookingViewModel
        //            {
        //                SeatReservedList = cachedData.Item1,
        //                MovieShowsList = cachedData.Item2
        //            };

        //            return View(viewModel);
        //        }
        //        else
        //        {
        //            var result = await _seat.SGetAllAsync(userName);
        //            List<SeatReserved> seatReservedList = result.Item1;
        //            List<MovieShows> movieShowsList = result.Item2;

        //            if (seatReservedList.Count == 0)
        //            {
        //                return RedirectToAction("NotBooking", "Movies");
        //            }
        //            else
        //            {
        //                cache.Add(_cacheKey, new Tuple<List<SeatReserved>, List<MovieShows>>(seatReservedList, movieShowsList), DateTimeOffset.UtcNow.AddMinutes(10)); // Example: Cache for 10 minutes

        //                BookingViewModel viewModel = new BookingViewModel
        //                {
        //                    SeatReservedList = seatReservedList,
        //                    MovieShowsList = movieShowsList
        //                };

        //                return View(viewModel);
        //            }
        //        }
        //    }
        //    else
        //    {
        //        return Content("Please login to continue.");
        //    }
        //}



        [Authorize(Policy = "PakistaniPolicy")]
        [Authorize(Policy = "LoggedInPolicy")]
        [HttpGet]
        public async Task<ViewResult> SeatSelection()
        {
            _logger.LogTrace("Seat Selection method started.");
            List<MovieShows> s = await _movie.GetAllAsync("Love Again");
            return View(s);
        }

        SeatReserved seats = new SeatReserved();
        [Authorize(Policy = "LoggedInPolicy")]
        [HttpPost]
        public async Task<IActionResult> SeatSelection(string user, string movie, int numSeats, string email, string text, string time)
        {
            MovieShows movieShows = new MovieShows();
            

            seats.Name = user;
            seats.Email = email;
            seats.NumSeats = numSeats;
            seats.Phone = text;
            seats.Movie = movie;
            seats.UserTime = time;
            seats.Price = await _seat.CalculatePriceAsync(numSeats);
            movieShows.Movie = movie;
            await _repository.AddAsync(seats);

            TempData["Booking"] = "Book";
            return RedirectToAction("Booking", "Movies");
        }

        [HttpPost]
        public async Task<ActionResult> CancelTicket()
        {
            string filePath = "D:\\Users\\fujitsu\\web project\\work\\LastMovieName.txt";

            try
            {
                _logger.LogTrace("Cancel Ticket method started.");
                string movieName = System.IO.File.ReadAllText(filePath);
                string userName = HttpContext.User.Identity.Name;
                await _repository.DeleteAsync(seats, movieName, userName);
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("File not found.");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("An error occurred: " + ex.Message);
            }
            _logger.LogTrace("Call to previou Booking method through cancel ticket.");
            return RedirectToAction("PreviousBooking", "Movies");
        }

        [HttpGet]
        public async Task<ViewResult> UpdateSeatSelection()
        {
            string userName = HttpContext.User.Identity.Name;
            seats = await _repository.GetAllAsync(userName);
            List<MovieShows> mv = await _movie.GetAllAsync("Love Again");

            SeatViewModel s = new SeatViewModel
            {
                Seat = seats,
                MovieShowsList = mv
            };

            _logger.LogTrace("Update Seat Selection method started.");
            HttpContext.Session.SetString("SeatData", JsonConvert.SerializeObject(s));
            return View(s);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateSeatSelection(string user, string movie, int numSeats, string email, string text, string time, string submitButton)
        {
            string seatData = HttpContext.Session.GetString("SeatData");
            SeatViewModel model = JsonConvert.DeserializeObject<SeatViewModel>(seatData);

            string userName = HttpContext.User.Identity.Name;
            SeatReserved p = new SeatReserved();

            p.Name = user ?? model.Seat.Name;
            p.Movie = movie ?? model.Seat.Movie;
            p.NumSeats = numSeats != 0 ? numSeats : model.Seat.NumSeats;
            p.Email = email ?? model.Seat.Email;
            p.UserTime = time ?? model.Seat.UserTime;
            p.Phone = text ?? model.Seat.Phone;
            p.Price = await _seat.CalculatePriceAsync(p.NumSeats);

            if (submitButton == "Update")
            {
                await _repository.UpdateAsync(p, userName);
            }

            return RedirectToAction("Booking", "Movies");
        }



        [HttpPost]
        public async Task<ActionResult> UpdateTicket()
        {
            return RedirectToAction("UpdateSeatSelection", "Movies");
        }

        public async Task<IActionResult> SearchMovie(string data)
        {
            _logger.LogTrace("Search Movie method started.");
            SeatRepo s = new SeatRepo();
            string imagepath = await s.GetpicAsync(data);
            string videomodal = await s.GetVideoModelAsync(data);
            return PartialView("_SearchMoviePartialView", new Tuple<string, string>(imagepath, videomodal));
        }

        [HttpPost]
        public async Task<ActionResult> UploadImage(IFormFile image)
        {
            _logger.LogTrace("Upload Image method started.");
            if (image != null && image.Length > 0)
            {
                var fileName = Path.GetFileName(image.FileName);
                var imageName = Path.GetFileNameWithoutExtension(image.FileName);
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Upload", fileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await image.CopyToAsync(fileStream);
                }
                var imageUrl = Url.Content("~/Upload/" + fileName);
                await _movie.AddMovieAsync(imageName, imageUrl);
                return Json(imageUrl);
            }

            _logger.LogTrace("No file selected");
            return Content("No file selected.");
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<string>>> GetUploadedImages()
        {
            var imageUrls = await _movie.GetMovieURLsAsync();
            return Json(imageUrls);
        }
    }
}





