﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using System.Diagnostics;
using Application;
using Domain.Entities;
using Domain.Interface;
using Infrastructure;
using Newtonsoft.Json;

namespace ProjectAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        private readonly IRepository<SeatReserved> _repository;
        private readonly IMovie _movie;
        private readonly SeatRepoDecorator _seat;
        private readonly IMemoryCache _cache;
        private readonly ILogger<MoviesController> _logger;

        public MoviesController(IMemoryCache cache, ILogger<MoviesController> logger, IRepository<SeatReserved> repository, SeatRepoDecorator seat, IMovie movie)
        {
            _repository = repository;
            _seat = seat;
            _movie = movie;
            _cache = cache;
            _logger = logger;
        }

        [HttpGet("GetMovies")]
        public IActionResult GetMovies()
        {
            _logger.LogTrace("Movies method started.");
            return Ok("Movies Page method placeholder.");
        }

        [HttpGet("NotBooking")]
        public IActionResult NotBooking()
        {
            _logger.LogTrace("Not Booking method started.");
            return Ok("Not Booking Page method placeholder.");
        }

        [HttpGet("UserPreviousbooking")]
        public async Task<IActionResult> GetPreviousBooking(string userName)
        {
            
            var result = await _seat.SGetAllAsync(userName);
            List<SeatReserved> seatReservedList = result.Item1;
            List<MovieShows> movieShowsList = result.Item2;

            _logger.LogTrace("Previous Booking method started.");

            BookingViewModel viewModel = new BookingViewModel
            {
                SeatReservedList = seatReservedList,
                MovieShowsList = movieShowsList
            };

            return Ok(viewModel);
        }


        [Authorize]
        [HttpGet("UserBooking")]
        public async Task<IActionResult> GetBooking(string userName)
        {
           
            List<SeatReserved> seatReservedList = new List<SeatReserved>();
            List<MovieShows> movieShowsList = new List<MovieShows>();

            if (string.IsNullOrEmpty(userName))
            {
                return Unauthorized("Please login to continue.");
            }

            if (!_cache.TryGetValue($"BookingData_{userName}", out (List<SeatReserved> cachedSeatReservedList, List<MovieShows> cachedMovieShowsList) cachedData))
            {
                _logger.LogTrace("Data stored in cache.");
                var result = await _seat.SGetAllAsync(userName);
                seatReservedList = result.Item1;
                movieShowsList = result.Item2;

                if (seatReservedList.Count == 0)
                {
                    return NotFound("No bookings found.");
                }

                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    .SetAbsoluteExpiration(TimeSpan.FromMinutes(5));
                _cache.Set($"BookingData_{userName}", (seatReservedList, movieShowsList), cacheEntryOptions);
            }
            else
            {
                _logger.LogTrace("Data retrieved from cache.");
                seatReservedList = cachedData.cachedSeatReservedList;
                movieShowsList = cachedData.cachedMovieShowsList;
            }

            var viewModel = new BookingViewModel
            {
                SeatReservedList = seatReservedList,
                MovieShowsList = movieShowsList
            };

            return Ok(viewModel);
        }



        SeatReserved seats = new SeatReserved();

        [HttpPost("EnterSeatSelection")]
        public async Task<IActionResult> PostSeatSelection(string user, string movie, int numSeats, string email, string text, string time)
        {
            MovieShows movieShows = new MovieShows();
            seats.Name = user;
            seats.Email = email;
            seats.NumSeats = numSeats;
            seats.Phone = text;
            seats.Movie = movie;
            seats.UserTime = time;
            seats.Price = await _seat.CalculatePriceAsync(numSeats);
            movieShows.Movie = movie;
            await _repository.AddAsync(seats);


            return Ok(new { message = "Seat selection has been successfully added." });
        }

        [HttpPost("CancelTicket")]
        public async Task<IActionResult> CancelTicket(string movieName, string userName)
        {
          
            try
            {
                _logger.LogTrace("Cancel Ticket method started.");
                await _repository.Delete2Async(seats, movieName, userName);
            }
            catch (FileNotFoundException)
            {
                return NotFound("File not found.");
            }
            catch (Exception ex)
            {
                _logger.LogError("An error occurred: " + ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred.");
            }

            _logger.LogTrace("Call to previous Booking method through cancel ticket.");
            return RedirectToAction("GetPreviousBooking", "Movies");
        }

        [HttpGet("UpdateSeatselectionPage")]
        public async Task<IActionResult> GetUpdateSeatSelection(string userName)
        {
            
            SeatReserved seats = await _repository.GetAllAsync(userName);
            List<MovieShows> mv = await _movie.GetAllAsync("Love Again");

            SeatViewModel s = new SeatViewModel
            {
                Seat = seats,
                MovieShowsList = mv
            };

            _logger.LogTrace("Update Seat Selection method started.");
            HttpContext.Session.SetString("SeatData", JsonConvert.SerializeObject(s));
            return Ok(s);
        }

        [HttpPost("UpdateSeatselection")]
        public async Task<IActionResult> PostUpdateSeatSelection(string user, string movie, int numSeats, string email, string text, string time, string submitButton)
        {
            
            SeatReserved p = new SeatReserved();

            p.Name = user;
            p.Movie = movie;
            p.NumSeats = numSeats;
            p.Email = email;
            p.UserTime = time;
            p.Phone = text;
            p.Price = await _seat.CalculatePriceAsync(p.NumSeats);

            if (submitButton == "Update")
            {
                await _repository.UpdateAsync(p, email);
            }

            return Ok(new { message = "Successfully updated." });

        }



        [HttpGet("Searchmovie")]
        public async Task<IActionResult> SearchMovie(string data)
        {
            _logger.LogTrace("Search Movie method started.");
            SeatRepo s = new SeatRepo();
            string imagepath = await s.GetpicAsync(data);
            string videomodal = await s.GetVideoModelAsync(data);
            return Ok(new { imagepath, videomodal });
        }

        [HttpPost("UploadImage")]
        public async Task<IActionResult> UploadImage(IFormFile image)
        {
            _logger.LogTrace("Upload Image method started.");

            // Define the path to the Upload directory
            var uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "Upload");

            // Ensure the Upload directory exists
            if (!Directory.Exists(uploadPath))
            {
                Directory.CreateDirectory(uploadPath);
            }

            if (image != null && image.Length > 0)
            {
                try
                {
                    var fileName = Path.GetFileName(image.FileName);
                    var imageName = Path.GetFileNameWithoutExtension(image.FileName);
                    var filePath = Path.Combine(uploadPath, fileName);

                    // Save the file to the Upload directory
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await image.CopyToAsync(fileStream);
                    }

                    // Create the image URL (adjust if you have a different URL structure)
                    var imageUrl = Url.Content($"~/Upload/{fileName}");

                    // Call your method to handle the image data
                    await _movie.AddMovieAsync(imageName, imageUrl);

                    return Ok(imageUrl);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "An error occurred while uploading the image.");
                    return StatusCode(500, "Internal server error");
                }
            }

            _logger.LogTrace("No file selected.");
            return BadRequest("No file selected.");
        }


        [HttpGet("GetUploadedimages")]
        public async Task<IActionResult> GetUploadedImages()
        {
            var imageUrls = await _movie.GetMovieURLsAsync();
            return Ok(imageUrls);
        }
    }
}
