﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Domain.Interface;
using Domain.Entities;
using Application;
using Infrastructure;

namespace Project_Task.Controllers
{
    //[Authorize(Policy = "PakistaniPolicy")]
    public class LoginController : Controller
    {
        string conn = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyNewDB;Integrated Security=True";

        private readonly IRepository<Contact> _repository;

        public LoginController(IRepository<Contact> repository)
        {
            _repository = repository;
        }

        public ViewResult Login()
        {
            return View();
        }
        public ViewResult SignUp()
        {
            return View();
        }

        public ViewResult Forgot()
        {
            return View();
        }
        [HttpGet]
        public ViewResult Contact()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Contact(string name, string email, string message)
        {
            //IRepository<Contact> repo = new Genericrepo<Contact>(conn);
            Contact c = new Contact();
            c.FullName = name;
            c.Email = email;
            c.Message = message;
            _repository.Simple_AddAsync(c, email);
            return RedirectToAction("Contact", "Login");
        }
    }
}
