using Application;
using Domain.Entities;
using Domain.Interface;
using Infrastructure;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using practice.Data;
using ProjectAPI.Hubs;
using System.Security.Claims;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

string conn = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyNewDB;Integrated Security=True";

// Configure DbContext with connection string
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(conn));

builder.Services.AddDatabaseDeveloperPageExceptionFilter();

// Add SignalR service
builder.Services.AddSignalR();

// Register your repositories
builder.Services.AddScoped<IRepository<SeatReserved>>(provider =>
    new Genericrepo<SeatReserved>(conn));
builder.Services.AddScoped<IRepository<Contact>>(provider =>
    new Genericrepo<Contact>(conn));
builder.Services.AddScoped<IMovie, MovieRepo>();
builder.Services.AddScoped<SeatRepoDecorator>();

// Add MemoryCache service
builder.Services.AddMemoryCache();

// Add Identity with the custom user class `MyUser`
builder.Services.AddDefaultIdentity<MyUser>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddEntityFrameworkStores<ApplicationDbContext>();

// Add MVC services with views
builder.Services.AddControllersWithViews();

var key = Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]);

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = "https://localhost:7032",
            ValidAudience = "https://localhost:7032",
            IssuerSigningKey = new SymmetricSecurityKey(key)
        };
    });


// Add session services
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(3);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// Add Authorization policies
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("LoggedInPolicy", policy =>
        policy.RequireAuthenticatedUser());

    options.AddPolicy("PakistaniPolicy", policy =>
        policy.RequireClaim(ClaimTypes.Country, "Pakistan"));

    options.AddPolicy("AdminOnly", policy =>
    {
        policy.RequireClaim(ClaimTypes.Email, "admin@gmail.com");
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseStaticFiles(); // This allows serving static files like CSS, JS, etc.

app.UseRouting();

// Enable session middleware
app.UseSession();

// Add authentication and authorization middleware
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.MapHub<ChatHub>("/chatHub"); // Use MapHub directly instead of UseEndpoints for SignalR hubs

app.Run();
