﻿using Microsoft.AspNetCore.SignalR;

namespace ProjectAPI.Hubs
{
    public class ChatHub : Hub
    {
        public async Task SendMessage(string m)
        {
            await Clients.All.SendAsync("ReceiveMessage", m);
          
        }
    }
}
