﻿using Domain.Entities;

namespace Domain.Interface
{
    public interface ISeat
    {
        public string[] SeatGenerator(int numSeats);
        public Task<string> CalculatePriceAsync(int numSeats);
        public Task<string> GetpicAsync(string movieName);

        public Task<Tuple<List<SeatReserved>, List<MovieShows>>> SGetAllAsync(string email);


        public Task<string> GetVideoModelAsync(string movieName);
    }
}
