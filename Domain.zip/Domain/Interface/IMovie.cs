﻿using Domain.Entities;

namespace Domain.Interface
{
    public interface IMovie
    {
        public Task AddMovieAsync(string moviename, string imagepath);
        public void DeleteMovie(string MovieName);
        public Task<List<MovieShows>> GetAllAsync(string movieName);

        public Task<List<string>> GetMovieURLsAsync();

    }
}
