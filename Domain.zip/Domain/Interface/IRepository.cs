﻿using System.Collections.Generic;

namespace Domain.Interface
{
    public interface IRepository<TEntity>
    {

        public Task<TEntity> GetAllAsync(string Email);
        public Task AddAsync(TEntity entity);
        public Task DeleteAsync(TEntity entity, string Movie, string Email);
        public Task Delete2Async(TEntity entity, string Movie, string Email);

        public Task UpdateAsync(TEntity entity, string Email);

        public Task Simple_AddAsync(TEntity entity, string email);
    }
}
