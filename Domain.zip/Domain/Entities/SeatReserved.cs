﻿namespace Domain.Entities
{
    public class SeatReserved
    {
        private string[] reservedSeats;
        public string[] ReservedSeats
        {
            get { return reservedSeats; }
            set { reservedSeats = value; }
        }

        private int numSeats;
        public int NumSeats
        {
            get { return numSeats; }
            set { numSeats = value; }
        }

        private string email;
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        private string movie;
        public string Movie
        {
            get { return movie; }
            set { movie = value; }
        }

        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private string phone;
        public string Phone
        {
            get { return phone; }
            set { phone = value; }
        }

        private string price;

        public string Price
        {
            get { return price; }
            set { price = value; }
        }

        private string userTime;

        public string UserTime
        {
            get { return userTime; }
            set { userTime = value; }
        }

    }
}


