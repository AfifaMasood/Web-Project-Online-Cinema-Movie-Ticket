﻿namespace Domain.Entities
{
    public class BookingViewModel
    {
        public List<SeatReserved> SeatReservedList { get; set; }
        public List<MovieShows> MovieShowsList { get; set; }
    }
}
