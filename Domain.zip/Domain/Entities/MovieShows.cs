﻿namespace Domain.Entities
{
    public class MovieShows
    {
        private string movie;

        public string Movie
        {
            get { return movie; }
            set { movie = value; }
        }

        private string image;
        public string Image
        {
            get { return image; }
            set { image = value; }
        }

        private string[] time;
        public string[] Time
        {
            get { return time; }
            set { time = value; }
        }


    }
}
