﻿namespace Domain.Entities
{
    public class SeatViewModel 
    {
        public SeatReserved Seat { get; set; }
        public List<MovieShows> MovieShowsList { get; set; }
    }
}
