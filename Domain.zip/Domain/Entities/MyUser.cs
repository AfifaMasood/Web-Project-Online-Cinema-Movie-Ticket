﻿using Microsoft.AspNetCore.Identity;

namespace Domain.Entities 
{
    public class MyUser : IdentityUser
    {
        public string FullName { get; set; }
        public string Country { get; set; }
    }
}
