﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.SqlServer.Server;
using System.Net;
using Domain;
using Application;
using System.ComponentModel.DataAnnotations;
using Dapper;
using System.Diagnostics;
using Domain.Interface;
using Domain.Entities;

namespace Infrastructure
{ 
    public class SeatRepo : ISeat
    {
       
        public string[] SeatGenerator(int numSeats)
        {
            string[] options = new string[numSeats];

            Random random = new Random();

            for (int i = 0; i < numSeats; i++)
            {
                char letter = (char)random.Next('A', 'Z' + 1); 
                int number = random.Next(1, 101); 
                options[i] = $"{letter}{number}";
            }

            return options;
        }

        public async Task<string> CalculatePriceAsync(int numSeats)
        {
            int pricePerSeat = 300;
            int totalPrice = numSeats * pricePerSeat;

            // Simulate some asynchronous operation
            await Task.Delay(100);

            return "$" + totalPrice.ToString();
        }
        //public void Add(SeatReserved seats)
        //{
        //    string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyNewDB;Integrated Security=True;";
        //    try
        //    {
        //        string[] reservedSeats = SeatGenerator(seats.NumSeats);
        //        string reservedSeatsString = string.Join(",", reservedSeats);


        //        string query = "INSERT INTO SeatsInfo (Name, NumSeats, ReservedSeats, Email, Phone, Movie, Price) VALUES (@value1, @value2, @value3, @value4, @value5, @value6, @value7)";
        //        SqlParameter userParam = new SqlParameter("@value1", seats.User);
        //        SqlParameter emailParam = new SqlParameter("@value4", seats.Email);
        //        SqlParameter numSeatsParam = new SqlParameter("@value2", seats.NumSeats);
        //        SqlParameter phoneParam = new SqlParameter("@value5", seats.PhoneNumber);
        //        SqlParameter seatParam = new SqlParameter("@value3", reservedSeatsString);
        //        SqlParameter movieParam = new SqlParameter("@value6", seats.Movie);
        //        SqlParameter priceParam = new SqlParameter("@value7", seats.Price);

        //        using (SqlConnection connection = new SqlConnection(connectionString))
        //        {
        //            connection.Open();

        //            SqlCommand command = new SqlCommand(query, connection);

        //            command.Parameters.Add(userParam);
        //            command.Parameters.Add(emailParam);
        //            command.Parameters.Add(numSeatsParam);
        //            command.Parameters.Add(phoneParam);
        //            command.Parameters.Add(seatParam);
        //            command.Parameters.Add(movieParam);
        //            command.Parameters.Add(priceParam);

        //            command.ExecuteNonQuery();

        //            connection.Close();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine("Error: " + ex.Message);
        //    }
        //}

        //public void Update(SeatReserved seatReserved) { }
        //public void Delete(SeatReserved seatReserved) { }
        //public void DeleteAll() { }

        public async Task<string> GetpicAsync(string movieName)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyNewDB;Integrated Security=True;";
            string picturePath = null;

            try
            {
                string query = "SELECT Image FROM MoviesPic WHERE MovieName = @movieName";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@movieName", movieName);

                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                picturePath = Convert.ToString(reader["Image"]);
                            }
                            else
                            {
                                await reader.CloseAsync();

                                string query2 = "SELECT MovieURL FROM UploadMovies WHERE Moviename = @movieName";

                                using (SqlConnection connection2 = new SqlConnection(connectionString))
                                {
                                    await connection2.OpenAsync();

                                    using (SqlCommand command2 = new SqlCommand(query2, connection2))
                                    {
                                        command2.Parameters.AddWithValue("@movieName", movieName);

                                        using (SqlDataReader reader2 = await command2.ExecuteReaderAsync())
                                        {
                                            if (await reader2.ReadAsync())
                                            {
                                                picturePath = Convert.ToString(reader2["MovieURL"]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to retrieve the picture path for the movie: " + ex.Message);
            }

            return picturePath;
        }

        //public Tuple<List<SeatReserved>, List<MovieShows>> GetAll(string email)
        //{
        //    string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyNewDB;Integrated Security=True;";
        //    List<SeatReserved> seatReservedList = new List<SeatReserved>();
        //    List<MovieShows> movieShowsList = new List<MovieShows>();


        //    try
        //    {
        //        string query = "SELECT * FROM SeatsInfo WHERE Email = @email";

        //        using (SqlConnection connection = new SqlConnection(connectionString))
        //        {
        //            connection.Open();

        //            SqlCommand command = new SqlCommand(query, connection);
        //            command.Parameters.AddWithValue("@email", email);

        //            SqlDataReader reader = command.ExecuteReader();

        //            if (reader.HasRows) // Check if any rows are returned
        //            {
        //                while (reader.Read())
        //                {
        //                    SeatReserved seatReserved = new SeatReserved
        //                    {

        //                        Name = Convert.ToString(reader[0]),
        //                        NumSeats = Convert.ToInt32(reader[1]),
        //                        ReservedSeats = new string[] { Convert.ToString(reader[2]) },
        //                        Email = Convert.ToString(reader[3]),
        //                        Phone = Convert.ToString(reader[4]),
        //                        Movie = Convert.ToString(reader[5]),
        //                        Price = Convert.ToString(reader[6]),
        //                        UserTime = Convert.ToString(reader[8])

        //                    };

        //                    MovieShows movieShows = new MovieShows
        //                    {
        //                        Movie = Convert.ToString(reader[5]),
        //                        Image = Getpic(Convert.ToString(reader[5]))
        //                    };

        //                    seatReservedList.Add(seatReserved);
        //                    movieShowsList.Add(movieShows);
        //                }

        //                string filePath = "D:\\Users\\fujitsu\\web project\\work\\LastMovieName.txt";
        //                File.WriteAllText(filePath, string.Empty);

        //                if (seatReservedList.Count > 0)
        //                {
        //                    string MovieName = seatReservedList[seatReservedList.Count - 1].Movie;
        //                    File.AppendAllText(filePath, MovieName);
        //                }
        //            }

        //            else
        //            {
        //                seatReservedList = new List<SeatReserved>();
        //            }

        //            reader.Close();
        //            connection.Close();
        //        }
        //    }
        //     catch (Exception ex)
        //    {
        //        Console.WriteLine("Error: " + ex.Message);
        //    }

        //    return new Tuple<List<SeatReserved>, List<MovieShows>>(seatReservedList, movieShowsList);
        //}

        public async Task<Tuple<List<SeatReserved>, List<MovieShows>>> SGetAllAsync(string email)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyNewDB;Integrated Security=True;";
            List<SeatReserved> seatReservedList = new List<SeatReserved>();
            List<MovieShows> movieShowsList = new List<MovieShows>();

            try
            {
                string query = "SELECT * FROM SeatsInfo WHERE Email = @Email";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();

                    var result = await connection.QueryAsync(query, new { Email = email });

                    foreach (var row in result)
                    {
                        SeatReserved seatReserved = new SeatReserved
                        {
                            Name = row.Name,
                            NumSeats = row.NumSeats,
                            ReservedSeats = new string[] { row.ReservedSeats },
                            Email = row.Email,
                            Phone = row.Phone,
                            Movie = row.Movie,
                            Price = row.Price,
                            UserTime = row.UserTime
                        };

                        MovieShows movieShows = new MovieShows
                        {
                            Movie = row.Movie,
                            Image = GetpicAsync(row.Movie)
                        };

                        seatReservedList.Add(seatReserved);
                        movieShowsList.Add(movieShows);
                    }

                    string filePath = "D:\\Users\\fujitsu\\web project\\work\\LastMovieName.txt";
                    await File.WriteAllTextAsync(filePath, string.Empty);

                    if (seatReservedList.Count > 0)
                    {
                        string MovieName = seatReservedList[seatReservedList.Count - 1].Movie;
                        await File.AppendAllTextAsync(filePath, MovieName);
                    }

                    await connection.CloseAsync();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine("Error: " + ex.Message);
            }

            return new Tuple<List<SeatReserved>, List<MovieShows>>(seatReservedList, movieShowsList);
        }


        public async Task<string> GetVideoModelAsync(string movieName)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyNewDB;Integrated Security=True;";
            string model = null;

            try
            {
                string query = "SELECT VideoModal FROM MoviesPic WHERE MovieName = @movieName";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@movieName", movieName);

                    SqlDataReader reader = await command.ExecuteReaderAsync();

                    if (await reader.ReadAsync())
                    {
                        model = Convert.ToString(reader["VideoModal"]);
                    }

                    await reader.CloseAsync();
                    await connection.CloseAsync();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine("Error: " + ex.Message);
            }

            return model;
        }
    }

   


}
