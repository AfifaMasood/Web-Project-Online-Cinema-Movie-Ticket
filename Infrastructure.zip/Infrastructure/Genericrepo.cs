﻿using Dapper;
using System.Data.SqlClient;
using Domain.Interface;
using Domain.Entities;
using Application;
using System.ComponentModel.DataAnnotations;
using static Dapper.SqlMapper;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Infrastructure
{
    public class Genericrepo<TEntity> : IRepository<TEntity> where TEntity : class
    {
        string connectionstring;
        SeatRepo s = new SeatRepo();
        public string[] SeatGenerator(int numSeats)
        {
            string[] options = new string[numSeats];

            Random random = new Random();

            for (int i = 0; i < numSeats; i++)
            {
                char letter = (char)random.Next('A', 'Z' + 1);
                int number = random.Next(1, 101);
                options[i] = $"{letter}{number}";
            }

            return options;
        }

        public string CalculatePrice(int numSeats)
        {
            int pricePerSeat = 300;
            int totalPrice = numSeats * pricePerSeat;

            return "$" + totalPrice.ToString();
        }



        public Genericrepo(string c)
        {
            connectionstring = c;
        }

        //public void Add(TEntity entity)
        //{
        //    int Seats = (int)entity.GetType().GetProperty("NumSeats").GetValue(entity);
        //    string email = (string)entity.GetType().GetProperty("Email").GetValue(entity);
        //    var reservedSeats = SeatGenerator(Seats);
        //    var reservedSeatsString = string.Join(",", reservedSeats);
        //    var tableName = typeof(TEntity).Name;
        //    tableName = tableName.Replace("Reserved", "") + "sInfo";
        //    var properties = typeof(TEntity).GetProperties().Where(p => p.Name != "ReservedSeats" && p.Name != "Picture");
        //    var columnNames = string.Join(",", properties.Where(p => p.Name != "ReservedSeats" && p.Name != "Picture").Select(p => p.Name));
        //    var parameterName = string.Join(",", properties.Where(p => p.Name != "ReservedSeats" && p.Name != "Picture").Select(p => "@" + p.Name));
        //    var query = $"INSERT INTO {tableName} ({columnNames}, ReservedSeats) VALUES ({parameterName}, @ReservedSeats)";
        //    using (var connection = new SqlConnection(connectionstring))
        //    {
        //        connection.Open();
        //        var command = new SqlCommand(query, connection);
        //        foreach (var property in properties)
        //        {
        //            command.Parameters.AddWithValue("@" + property.Name, property.GetValue(entity));

        //        }
        //        command.Parameters.AddWithValue("@ReservedSeats", reservedSeatsString);
        //        command.ExecuteNonQuery();
        //    }
        //}

        public async Task AddAsync(TEntity entity)
        {
            int Seats = (int)entity.GetType().GetProperty("NumSeats").GetValue(entity);
            string email = (string)entity.GetType().GetProperty("Email").GetValue(entity);
            var reservedSeats = SeatGenerator(Seats);
            var reservedSeatsString = string.Join(",", reservedSeats);
            var tableName = typeof(TEntity).Name;
            tableName = tableName.Replace("Reserved", "") + "sInfo";
            var properties = typeof(TEntity).GetProperties().Where(p => p.Name != "ReservedSeats" && p.Name != "Picture");
            var columnNames = string.Join(",", properties.Where(p => p.Name != "ReservedSeats" && p.Name != "Picture").Select(p => p.Name));
            var parameterName = string.Join(",", properties.Where(p => p.Name != "ReservedSeats" && p.Name != "Picture").Select(p => "@" + p.Name));

            using (SqlConnection conn = new SqlConnection(connectionstring))
            {
                var query = $"INSERT INTO {tableName} ({columnNames}, ReservedSeats) VALUES ({parameterName}, @ReservedSeats)";

                var parameters = properties.ToDictionary(p => "@" + p.Name, p => p.GetValue(entity));

                parameters.Add("@ReservedSeats", reservedSeatsString);

                await conn.ExecuteAsync(query, parameters);
            }
        }

        //public void Delete(TEntity entity, string Movie,string Email)
        //{
        //    var tableName = typeof(TEntity).Name;
        //    tableName = tableName.Replace("Reserved", "") + "sInfo";

        //    var query = $"DELETE FROM {tableName} WHERE Email = @Email AND Movie = @Movie AND ID = (SELECT MAX(ID) FROM {tableName} WHERE Email = @Email)";
        //    using (var connection = new SqlConnection(connectionstring))
        //    {
        //        connection.Open();
        //        var sqlCommand = new SqlCommand(query, connection);

        //        // Add both parameters with their values
        //        sqlCommand.Parameters.AddWithValue("@Email", Email);
        //        sqlCommand.Parameters.AddWithValue("@Movie", Movie);

        //        sqlCommand.ExecuteNonQuery();
        //    }
        //}

        public async Task DeleteAsync(TEntity entity, string Movie, string Email)
        {
            var tableName = typeof(TEntity).Name;
            tableName = tableName.Replace("Reserved", "") + "sInfo";

            using (SqlConnection conn = new SqlConnection(connectionstring))
            {
                var query = $"DELETE FROM {tableName} WHERE Email = @Email AND Movie = @Movie AND ID = (SELECT MAX(ID) FROM SeatsInfo WHERE Email = @Email)";
                var parameters = new { Email, Movie };

                await conn.ExecuteAsync(query, parameters);
            }
        }

        public async Task Delete2Async(TEntity entity, string Movie, string Email)
        {
            var tableName = typeof(TEntity).Name;
            tableName = tableName.Replace("Reserved", "") + "sInfo";

            using (SqlConnection conn = new SqlConnection(connectionstring))
            {
                var query = $"DELETE FROM {tableName} WHERE Email = @Email AND Movie = @Movie";
                var parameters = new { Email, Movie };

                await conn.ExecuteAsync(query, parameters);
            }
        }

        //public void Update(TEntity entity)
        //{
        //    var tableName = typeof(TEntity).Name;
        //    var email = entity.GetType().GetProperty("Email").GetValue(entity);
        //    var properties = typeof(TEntity).GetProperties(); 

        //    var setClause = string.Join(",", properties.Select(a => $"{a.Name} = @{a.Name}"));

        //    var query = $"UPDATE {tableName} SET {setClause} WHERE Email = @email";

        //    using (var connection = new SqlConnection(connectionstring))
        //    {
        //        connection.Open();
        //        SqlCommand command = new SqlCommand(query, connection);

        //        foreach (var property in properties)
        //        {
        //            var value = property.GetValue(entity);
        //            command.Parameters.AddWithValue("@" + property.Name, value ?? DBNull.Value);
        //        }
        //        command.ExecuteNonQuery();
        //    }
        //}

        public async Task UpdateAsync(TEntity entity, string Email)
        {
            int Seats = (int)entity.GetType().GetProperty("NumSeats").GetValue(entity);
            var tableName = typeof(TEntity).Name.Replace("Reserved", "") + "sInfo";
            var reservedSeats = SeatGenerator(Seats);
            var reservedSeatsString = string.Join(",", reservedSeats);
            var properties = typeof(TEntity).GetProperties().Where(p => p.Name != "ReservedSeats" && p.Name != "Picture");

            var columnNames = string.Join(",", properties.Select(p => $"{p.Name} = @{p.Name}"));
            columnNames += ", ReservedSeats = @ReservedSeats";

            using (SqlConnection conn = new SqlConnection(connectionstring))
            {
                var query = $"UPDATE {tableName} SET {columnNames} WHERE Email = @Email AND ID = (SELECT MAX(ID) FROM SeatsInfo WHERE Email = @Email)";
                var parameters = properties.ToDictionary(p => "@" + p.Name, p => p.GetValue(entity));
                parameters.Add("@ReservedSeats", reservedSeatsString);

                await conn.ExecuteAsync(query, parameters);
            }
        }
        public async Task<TEntity> GetAllAsync(string Email)
        {
            var tableName = typeof(TEntity).Name;
            tableName = tableName.Replace("Reserved", "") + "sInfo";

            using (SqlConnection conn = new SqlConnection(connectionstring))
            {
                var query = $"SELECT Name,NumSeats,Email,Phone,Movie,UserTime FROM {tableName} WHERE Email = @Email AND ID = (SELECT MAX(ID) FROM SeatsInfo WHERE Email = @Email)";

                var parameters = new { Email };

                return await conn.QuerySingleOrDefaultAsync<TEntity>(query, parameters);
            }
        }

        public async Task Simple_AddAsync(TEntity entity, string email)
        {
            var tableName = typeof(TEntity).Name;
            var properties = typeof(TEntity).GetProperties();
            var columnNames = string.Join(",", properties.Select(p => p.Name));
            var parameterName = string.Join(",", properties.Select(p => "@" + p.Name));

            using (SqlConnection conn = new SqlConnection(connectionstring))
            {
                var query = $"INSERT INTO {tableName} ({columnNames}) VALUES ({parameterName})";

                await conn.ExecuteAsync(query, entity);
            }
        }


        //public void Connectionstring(string c)
        //{
        //    connectionstring = c;
        //}
    }
}
