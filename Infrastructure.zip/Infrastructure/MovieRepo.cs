﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.SqlServer.Server;
using System.Net;
using System.ComponentModel.DataAnnotations;
using Domain.Entities;
using Domain.Interface;
using Application;
using System.Diagnostics;

namespace Infrastructure
{
    public class MovieRepo : IMovie
    {
        public async Task AddMovieAsync(string moviename, string imagepath)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyNewDB;Integrated Security=True;";

            try
            {
                string query = "INSERT INTO UploadMovies (MovieName, MovieURL) VALUES (@value1, @value2)";
                SqlParameter userParam = new SqlParameter("@value1", moviename);
                SqlParameter emailParam = new SqlParameter("@value2", imagepath);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();

                    SqlCommand command = new SqlCommand(query, connection);

                    command.Parameters.Add(userParam);
                    command.Parameters.Add(emailParam);

                    await command.ExecuteNonQueryAsync();

                    await connection.CloseAsync();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine("Error: " + ex.Message);
            }
        }

        public void DeleteMovie(string MovieName)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyNewDB;Integrated Security=True;";
            try
            {
                // Use a parameterized query to prevent SQL injection
                string query = "DELETE FROM MoviesPic WHERE MovieName = @MovieName";  // Corrected the query syntax

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand(query, connection);

                    // Set the parameter value
                    command.Parameters.AddWithValue("@MovieName", MovieName);

                    command.ExecuteNonQuery();

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine("Error: " + ex.Message);
            }
        }

        public async Task<List<MovieShows>> GetAllAsync(string movieName)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyNewDB;Integrated Security=True;";
            List<MovieShows> movieShowsList = new List<MovieShows>();

            try
            {
                string query = "SELECT * FROM MovieTimings WHERE MovieID IN (SELECT MovieID FROM MoviesPic WHERE MovieName = @MovieName)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@MovieName", movieName);

                    SqlDataReader reader = await command.ExecuteReaderAsync();

                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync())
                        {
                            string timeString = Convert.ToString(reader["Timing"]);
                            string[] times = timeString.Split(','); // Split the string by the delimiter (e.g., comma) to get an array of times

                            MovieShows movieShows = new MovieShows
                            {
                                Time = times,
                                // Set other properties of the MovieShows object as needed
                            };

                            movieShowsList.Add(movieShows);
                        }
                    }

                    await reader.CloseAsync();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine("Error: " + ex.Message);
            }

            return movieShowsList;
        }

        public async Task<List<string>> GetMovieURLsAsync()
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyNewDB;Integrated Security=True;";
            List<string> movieUrls = new List<string>();

            try
            {
                string query = "SELECT MovieURL FROM UploadMovies";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();

                    SqlCommand command = new SqlCommand(query, connection);

                    SqlDataReader reader = await command.ExecuteReaderAsync();

                    if (await reader.ReadAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            string movieUrl = Convert.ToString(reader["MovieURL"]);
                            movieUrls.Add(movieUrl);
                        }
                    }

                    await reader.CloseAsync();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine("Error: " + ex.Message);
            }

            return movieUrls;
        }


    }
}

