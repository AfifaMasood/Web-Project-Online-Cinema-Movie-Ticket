﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Threading.Tasks;
using Dapper;
using Domain.Entities;
using Domain.Interface;

namespace Application
{
    public class SeatRepoDecorator : IRepository<SeatReserved>
    {
        private readonly IRepository<SeatReserved> _repository;

        public SeatRepoDecorator(IRepository<SeatReserved> repository)
        {
            _repository = repository;
        }

        public async Task AddAsync(SeatReserved entity)
        {
            await _repository.AddAsync(entity);
        }

        public async Task DeleteAsync(SeatReserved entity, string Movie, string Email)
        {
            await _repository.DeleteAsync(entity, Movie, Email);
        }

        public async Task UpdateAsync(SeatReserved entity, string Email)
        {
            await _repository.UpdateAsync(entity, Email);
        }

        public async Task<SeatReserved> GetAllAsync(string email)
        {
            return await _repository.GetAllAsync(email);
        }

        public async Task Delete2Async(SeatReserved entity, string Movie, string Email)
        {
            await _repository.Delete2Async(entity, Movie, Email);
        }

        public string[] SeatGenerator(int numSeats)
        {
            string[] options = new string[numSeats];

            Random random = new Random();

            for (int i = 0; i < numSeats; i++)
            {
                char letter = (char)random.Next('A', 'Z' + 1);
                int number = random.Next(1, 101);
                options[i] = $"{letter}{number}";
            }

            return options;
        }

        public async Task<string> CalculatePriceAsync(int numSeats)
        {
            int pricePerSeat = 300;
            int totalPrice = numSeats * pricePerSeat;

            // Simulate some asynchronous operation
            await Task.Delay(100);

            return "$" + totalPrice.ToString();
        }

        public async Task Simple_AddAsync(SeatReserved entity, string email)
        {
            await _repository.Simple_AddAsync(entity, email);
        }

        public async Task<string> GetpicAsync(string movieName)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyNewDB;Integrated Security=True;";
            string picturePath = null;

            try
            {
                string query = "SELECT Image FROM MoviesPic WHERE MovieName = @movieName";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@movieName", movieName);

                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                picturePath = Convert.ToString(reader["Image"]);
                            }
                            else
                            {
                                await reader.CloseAsync();

                                string query2 = "SELECT MovieURL FROM UploadMovies WHERE Moviename = @movieName";

                                using (SqlConnection connection2 = new SqlConnection(connectionString))
                                {
                                    await connection2.OpenAsync();

                                    using (SqlCommand command2 = new SqlCommand(query2, connection2))
                                    {
                                        command2.Parameters.AddWithValue("@movieName", movieName);

                                        using (SqlDataReader reader2 = await command2.ExecuteReaderAsync())
                                        {
                                            if (await reader2.ReadAsync())
                                            {
                                                picturePath = Convert.ToString(reader2["MovieURL"]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to retrieve the picture path for the movie: " + ex.Message);
            }

            return picturePath;
        }

        public async Task<Tuple<List<SeatReserved>, List<MovieShows>>> SGetAllAsync(string email)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyNewDB;Integrated Security=True;";
            List<SeatReserved> seatReservedList = new List<SeatReserved>();
            List<MovieShows> movieShowsList = new List<MovieShows>();

            try
            {
                string query = "SELECT * FROM SeatsInfo WHERE Email = @Email";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();

                    var result = await connection.QueryAsync(query, new { Email = email });

                    foreach (var row in result)
                    {
                        SeatReserved seatReserved = new SeatReserved
                        {
                            Name = row.Name,
                            NumSeats = row.NumSeats,
                            ReservedSeats = new string[] { row.ReservedSeats },
                            Email = row.Email,
                            Phone = row.Phone,
                            Movie = row.Movie,
                            Price = row.Price,
                            UserTime = row.UserTime
                        };

                        MovieShows movieShows = new MovieShows
                        {
                            Movie = row.Movie,
                            Image = await GetpicAsync(row.Movie)
                        };

                        seatReservedList.Add(seatReserved);
                        movieShowsList.Add(movieShows);
                    }

                    string filePath = "D:\\Users\\fujitsu\\web project\\work\\LastMovieName.txt";
                    await File.WriteAllTextAsync(filePath, string.Empty);

                    if (seatReservedList.Count > 0)
                    {
                        string MovieName = seatReservedList[seatReservedList.Count - 1].Movie;
                        await File.AppendAllTextAsync(filePath, MovieName);
                    }

                    await connection.CloseAsync();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine("Error: " + ex.Message);
            }

            return new Tuple<List<SeatReserved>, List<MovieShows>>(seatReservedList, movieShowsList);
        }

        public async Task<string> GetVideoModel(string movieName)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyNewDB;Integrated Security=True;";
            string model = null;

            try
            {
                string query = "SELECT VideoModal FROM MoviesPic WHERE MovieName = @movieName";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@movieName", movieName);

                    SqlDataReader reader = await command.ExecuteReaderAsync();

                    if (await reader.ReadAsync())
                    {
                        model = Convert.ToString(reader["VideoModal"]);
                    }

                    await reader.CloseAsync();
                    await connection.CloseAsync();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine("Error: " + ex.Message);
            }

            return model;
        }



    }
}